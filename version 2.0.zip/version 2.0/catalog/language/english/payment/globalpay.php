<?php
// Text
$_['text_title'] = '<img src="admin/view/image/payment/globalpay-payment-logo.png" alt="GlobalPay Payment Gateway" title="GlobalPay Payment Gateway" />';
$_['text_reason'] 	= 'REASON';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';
?>